from django.apps import AppConfig


class OrderhandlerappConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "orderHandlerApp"
